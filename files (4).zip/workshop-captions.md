# Workshop Marketing Pack
**Monday, September 7, 2026 · 12:00–1:30 PM ET · Live on Zoom · Free**
Link for every post: **jeanpaulu.com/workshop.html**

Graphics in this folder:
- `workshop-square-EN.png` / `workshop-square-ES.png` — Instagram & LinkedIn feed posts
- `workshop-story-EN.png` / `workshop-story-ES.png` — Instagram/Facebook Stories, WhatsApp status

---

## INSTAGRAM — Feed post

**English** (use `workshop-square-EN.png`)

> Nobody explains the part where you lose money.
>
> On September 7 I'm going live for 90 minutes and walking through how real estate investing actually works in this country — the whole path, from finding a house to closing on it. Including the places where deposits disappear.
>
> What we cover:
> · Wholesaling — what you're actually signing
> · Comps before you walk the house, and why that order matters
> · Hard money, straight. Yes, credit gets checked.
> · Trigon running the numbers live on a real property
>
> Free. On Zoom. Nothing is sold during the first 80 minutes — that's the rule.
>
> All the workbooks are already on the site, English and Spanish. Link in bio.
>
> #realestateinvesting #fixandflip #miamirealestate #hardmoneylending #realestateinvestor #floridarealestate #wholesaling #realestatecoaching

**Español** (use `workshop-square-ES.png`)

> Nadie explica la parte donde se pierde el dinero.
>
> El 7 de septiembre me conecto en vivo por 90 minutos y explico cómo funciona de verdad la inversión inmobiliaria en este país — el camino completo, desde encontrar una casa hasta cerrarla. Incluyendo dónde se pierden los depósitos.
>
> Lo que vamos a cubrir:
> · Wholesaling — qué está firmando realmente
> · Los comparables antes de ver la casa, y por qué ese orden importa
> · Hard money, sin rodeos. Sí se mira el crédito.
> · Trigon corriendo los números en vivo sobre una casa real
>
> Gratis. Por Zoom. No se vende nada durante los primeros 80 minutos — esa es la regla.
>
> Los cuadernos ya están en la página, en inglés y español. Link en la bio.
>
> #inversionistas #bienesraices #inversioninmobiliaria #miami #floridarealestate #hardmoney #fixandflip

---

## INSTAGRAM — Story (3 frames)

Use `workshop-story-EN.png` / `workshop-story-ES.png` on frame 1, then plain text frames.

**Frame 1** — the graphic. Add a "Link" sticker to jeanpaulu.com/workshop.html
**Frame 2 (EN)** — "90 minutes. No pitch for the first 80. That's the rule."
**Frame 2 (ES)** — "90 minutos. Sin venta durante los primeros 80. Esa es la regla."
**Frame 3 (EN)** — "Workbooks are free on the site. English and Spanish. ⬆️"
**Frame 3 (ES)** — "Los cuadernos son gratis en la página. Inglés y español. ⬆️"

---

## WHATSAPP — Broadcast message

**English**

> Hi — Jean Paul here.
>
> I'm running a free workshop on Zoom, **Monday September 7 at 12:00 PM ET**. Ninety minutes on how real estate investing actually works in the United States: what a wholesaler puts in front of you, what it really takes to qualify for a private loan, how to run the numbers before you ever walk the house — and how people lose money doing this.
>
> Nothing gets sold during the first 80 minutes. That's the rule.
>
> The workbooks and checklists are already on the page, free, in English and Spanish. You can fill them out online or download the PDFs.
>
> jeanpaulu.com/workshop.html
>
> If you have questions, just reply here.
> — Jean Paul Urquizo · Nork Group

**Español**

> Hola — le habla Jean Paul.
>
> Voy a dar un taller gratuito por Zoom el **lunes 7 de septiembre a las 12:00 PM ET**. Noventa minutos sobre cómo funciona de verdad la inversión inmobiliaria en Estados Unidos: qué contrato le pone enfrente un wholesaler, qué se necesita realmente para calificar a un préstamo privado, cómo correr los números antes de ver la casa — y cómo se pierde el dinero en este negocio.
>
> No se vende nada durante los primeros 80 minutos. Esa es la regla.
>
> Los cuadernos y las listas de verificación ya están en la página, gratis, en inglés y español. Los puede llenar en línea o descargar en PDF.
>
> jeanpaulu.com/workshop.html
>
> Si tiene preguntas, responda por aquí.
> — Jean Paul Urquizo · Nork Group

---

## LINKEDIN

**English**

> Most real estate education skips the uncomfortable part.
>
> After twenty years in finance and investing, the pattern I see over and over isn't that people pick bad houses. It's that they break the order of operations — they walk the property before they run the comps, they sign before they read, and they look for financing after the offer instead of before it.
>
> On September 7 I'm hosting a free 90-minute session on Zoom covering the full path from search to closing: what a wholesaler is actually selling you, what documents a private lender genuinely requires, and how to model a deal before you commit a dollar.
>
> We'll run a real property live using our analysis tools so you can see the math, not just hear about it.
>
> No guaranteed returns. No countdown timers. Nothing sold during the first 80 minutes.
>
> Registration and all workshop materials — free, in English and Spanish — are at jeanpaulu.com/workshop.html
>
> Jean Paul Urquizo
> Nork Group · Nork Capital Lending · Trigon

**Español**

> La mayoría de la educación inmobiliaria se salta la parte incómoda.
>
> Después de veinte años en finanzas e inversiones, el patrón que veo una y otra vez no es que la gente elija casas malas. Es que rompen el orden: ven la propiedad antes de correr los comparables, firman antes de leer, y buscan financiamiento después de la oferta en vez de antes.
>
> El 7 de septiembre voy a dar una sesión gratuita de 90 minutos por Zoom sobre el camino completo, de la búsqueda al cierre: qué le está vendiendo realmente un wholesaler, qué documentos pide de verdad un prestamista privado, y cómo modelar un negocio antes de comprometer un dólar.
>
> Vamos a correr una propiedad real en vivo con nuestras herramientas de análisis para que vea los números, no solo que se los cuenten.
>
> Sin retornos garantizados. Sin cronómetros. Sin venta durante los primeros 80 minutos.
>
> Registro y todos los materiales — gratis, en inglés y español — en jeanpaulu.com/workshop.html
>
> Jean Paul Urquizo
> Nork Group · Nork Capital Lending · Trigon

---

## X (TWITTER)

**English — single post**

> Free workshop, Sept 7, 12pm ET on Zoom.
>
> 90 minutes on how real estate investing actually works — wholesaling contracts, hard money requirements, running comps before you walk the house, and how people lose money doing this.
>
> Nothing sold in the first 80 minutes.
>
> jeanpaulu.com/workshop.html

**English — thread version**

> 1/ Most people lose money in real estate for one reason: they break the order of operations.
>
> 2/ They walk the house before they run the comps. They sign before they read the contract. They look for financing after the offer instead of before it.
>
> 3/ Every one of those is fixable, and none of it is complicated. It just doesn't get taught, because "here's how you lose money" doesn't sell courses.
>
> 4/ So I'm doing it free. Sept 7, 12pm ET, 90 minutes on Zoom. The full path from finding a property to closing on it.
>
> 5/ Workbooks and checklists are already on the page, English and Spanish, no signup needed to download them: jeanpaulu.com/workshop.html

**Español**

> Taller gratuito. 7 de septiembre, 12pm ET, por Zoom.
>
> 90 minutos sobre cómo funciona de verdad la inversión inmobiliaria — contratos de wholesaling, requisitos de hard money, comparables antes de ver la casa, y cómo se pierde el dinero en esto.
>
> No se vende nada en los primeros 80 minutos.
>
> jeanpaulu.com/workshop.html

---

## FACEBOOK

**English**

> Free live workshop — Monday, September 7 at 12:00 PM ET on Zoom.
>
> I've spent twenty years in finance and real estate, and I'm going to spend ninety minutes walking through how this business actually works in the United States. Not the highlight reel — the real path, including the parts where people lose their deposit.
>
> We'll cover wholesaling contracts, what private lenders actually require, how to analyze a deal before you make an offer, and I'll run a real property live on screen so you can watch the numbers come together.
>
> The workbooks, checklists and the traffic-light self-assessment are already on the page. Free, English and Spanish, no email required to download.
>
> 👉 jeanpaulu.com/workshop.html

**Español**

> Taller gratuito en vivo — lunes 7 de septiembre a las 12:00 PM ET por Zoom.
>
> Llevo veinte años en finanzas y bienes raíces, y voy a dedicar noventa minutos a explicar cómo funciona este negocio de verdad en Estados Unidos. No la versión bonita — el camino real, incluyendo las partes donde la gente pierde su depósito.
>
> Vamos a cubrir contratos de wholesaling, qué piden realmente los prestamistas privados, cómo analizar un negocio antes de hacer una oferta, y voy a correr una propiedad real en pantalla para que vea cómo se arman los números.
>
> Los cuadernos, las listas y el semáforo de autoevaluación ya están en la página. Gratis, en inglés y español, sin necesidad de dar correo para descargarlos.
>
> 👉 jeanpaulu.com/workshop.html

---

## POSTING SCHEDULE

With the workshop on September 7, here's a workable rhythm:

| When | What | Where |
|---|---|---|
| 10 days out | Announcement post | Instagram, Facebook, LinkedIn |
| 8 days out | WhatsApp broadcast to your list | WhatsApp |
| 7 days out | X post or thread | X |
| 5 days out | Story series (3 frames) | Instagram, Facebook |
| 3 days out | Re-share the feed post, new caption angle | Instagram |
| 1 day out | "Tomorrow" reminder | WhatsApp, Stories |
| Morning of | "Today at 12" + Zoom link | WhatsApp, Stories |

**Two things that matter more than the copy:**

Reply to every comment within the first hour of posting. Instagram and LinkedIn both weight early engagement heavily, and a post that gets replies in the first hour reaches several times more people than one that doesn't.

Send the recording to everyone who registered, whether they showed up or not. No-shows who watch the replay become clients at a surprisingly similar rate to live attendees, and it costs you nothing.
